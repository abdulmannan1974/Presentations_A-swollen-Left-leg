# Before You Tick the Box

Grand round · Friday 9 October 2026 · Dr Abdul Mannan FCPS FRCPath

Clinical Director, Bangor Haemophilia Centre  
Thrombosis Lead, Glan Clwyd Hospital  
Clinical Haematology Lab Lead, Betsi Cadwaladr University Health Board

Open **Clot-First-Before-You-Tick-the-Box.html** in Chrome, Edge or Safari. This is the revised original presentation: light theme, larger text, no product branding, the original story and proximal DVT progression, plus the newer clot-growth and lupus anticoagulant animations. It works offline with no remote fonts or scripts.

- **21 main slides:** suggested delivery totals 15 minutes, including brief audience pauses.
- **2 reference slides:** full assay matrix and linked sources, after the closing slide.
- **Right arrow / Space / click:** reveal the next step, then advance. **Left arrow:** reverse a reveal or go back.
- **Sound effects on slide 2:** a clap accompanies the “One job done” stamp; glass shatters as “None” appears. Both sounds are embedded and work offline. **M** toggles mute in the audience or presenter window.
- **F:** fullscreen. **N:** show or hide speaker notes on the current screen.
- **S:** open a separate presenter window with current/next slide, script and elapsed timer.
- **O:** slide overview. **Esc:** close overview or notes. **T:** optional light/dark toggle; the deck opens in light mode.
- The timer starts on the first advance. Reload to reset it.
- Presenter mode may require allowing a pop-up. Keep the presenter window on your own display and put the audience window on the projector. Arrows, Space and T also work in the presenter window.
- The six quiz cards can be flipped with successive advances or by clicking the individual cards.

**Clot-First-PDF-Backup.pdf** is the static backup with all reveals and answers visible. **Presenter-Script.md** contains the full script and suggested elapsed times. Rehearse once: speaking pace and audience discussion determine the actual duration.

**Clot-First-Algorithms.drawio** contains two editable supplementary algorithms: acute-clot priorities and the two questions before ordering a test. Matching SVGs are included in the same light palette. They summarise the talk rather than reproducing its more detailed NICE and testing-indication slides.

The talk uses a UK BSH/NICE framework with ESC PE risk stratification and ESVS vascular guidance. It is teaching material, not a new local prescribing or referral protocol. The returning case is fictional. The source HTML and checklist have been preserved.
